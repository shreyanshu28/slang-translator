This is the Grammarly's Yahoo Answers Formality Corpus (GYAFC) described in the paper: "Dear Sir or Madam, May I introduce the GYAFC Corpus: Corpus, Benchmarks and Metrics for Formality Style Transfer".
It has data from two domains of Yahoo Answers: Entertainment & Music and Family & Relationships.
For each of the two domains, we provide the train, tune and the test split of the GYAFC corpus.
We also provide the output of following five models described in the paper: 
1. Rule Based
2. PBMT
3. NMT Baseline
4. NMT Copy
5. NMT Combined
